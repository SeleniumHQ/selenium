License
=======

.. include:: ../LICENSE.rst
