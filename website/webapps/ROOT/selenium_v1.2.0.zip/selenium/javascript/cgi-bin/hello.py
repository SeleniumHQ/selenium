"""
Simple CGI for 'Hello, World'. Requires Python.
"""
import cgi
print 'Content-type: text/html\n\n'
print 'hello, world!'
