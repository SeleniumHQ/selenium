package com.thoughtworks.selenium;

import org.jmock.MockObjectTestCase;

import java.io.IOException;

/**
 * @author Aslak Helles&oslash;y
 * @version $Revision: 1.1.1.1 $
 */
public class SeleniumServerTest extends MockObjectTestCase {
    public void testShouldReturnWikiTable() throws IOException {
//        new SeleniumServer().start();
    }
}
