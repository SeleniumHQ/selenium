package com.thoughtworks.selenium;

import java.io.IOException;

/**
 * @author Aslak Helles&oslash;y
 * @version $Revision: 1.1.1.1 $
 */
public interface SeleniumServer {
    void start();
    void shutdown();
}
